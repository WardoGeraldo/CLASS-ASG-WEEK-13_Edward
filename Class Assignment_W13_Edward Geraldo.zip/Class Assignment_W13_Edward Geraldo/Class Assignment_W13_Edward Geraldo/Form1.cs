﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Runtime.Remoting.Contexts;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using MySql.Data.MySqlClient;


namespace Class_Assignment_W13_Edward_Geraldo
{
    public partial class mainForm : Form
    {
        MySqlConnection SqlConnect;
        MySqlCommand SqlCommand;
        MySqlDataAdapter SqlDataAdapter;
        DataTable dt;
        string SqlQuery;
        public mainForm()
        {
            InitializeComponent();
        }

        private void mainForm_Load(object sender, EventArgs e)
        {
            SqlConnect = new MySqlConnection($"server = localhost; uid = student; pwd = isbmantap; database = premier_league;");
            dt = new DataTable();
            //SqlQuery = "select m.manager_name as 'Nama', ifnull(concat(t.team_name, ', ', t.city), 'Available') as Kesanggupan from manager m left join team t on m.manager_id = t.manager_id OR m.manager_id = t.assmanager_id";
            //SqlQuery = "select m.manager_name as 'Nama Manager', ifnull(concat('Stadium ', t.home_stadium, ' (', t.city, ')'), concat('(', n.nation, ')')) as alamat from manager m left join team t on m.manager_id = t.manager_id left join nationality n on m.nationality_id = n.nationality_id;";
            //SqlQuery = "select t.team_name as 'Team Name', concat(t.home_stadium, concat(' (',t.capacity,')')) as 'Stadium and Capacity', t.city as 'City', m.manager_name as 'Manager Name', m2.manager_name as 'Assistant Manager'\r\nfrom team t\r\nleft join manager m\r\non m.manager_id = t.manager_id \r\nleft join manager m2\r\non t.assmanager_id = m2.manager_id\r\n;\r\n";
            //SqlQuery = "select m.match_date, concat(t.team_name,' vs ', t2.team_name) as 'Match', concat(m.goal_home, ' - ', m.goal_away) as 'Hasil Akhir', concat(if(m.goal_home = m.goal_away, 'Draw',if(m.goal_home > m.goal_away, concat(t.team_name,' Win'), concat(t2.team_name,' Win')))) as 'Kesimpulan'\r\nfrom `match` m\r\nleft join team t\r\non m.team_home = t.team_id or  t.team_id = t.team_name\r\nleft join team t2\r\non m.team_away = t2.team_id or t2.team_id = t.team_name;\r\n";
            SqlQuery = "select t.team_name as 'Nama Team', concat(m.manager_name, ' & ', m2.manager_name) as 'Manager & Assistant Manager', p.player_name as 'Captain Name'\r\nfrom team t\r\nleft join manager m\r\non m.manager_id = t.manager_id \r\nleft join manager m2\r\non t.assmanager_id = m2.manager_id\r\nleft join player p\r\non p.player_id = t.captain_id\r\n;\r\n";
            SqlCommand = new MySqlCommand(SqlQuery, SqlConnect);
            SqlDataAdapter = new MySqlDataAdapter(SqlCommand);
            SqlDataAdapter.Fill(dt);
            dgv.DataSource = dt;
        }
    }
}
